//prettier-ignore
chrome.notifications.onClicked.addListener((notifID) => {
    console.log('User clicked the notification.')
    chrome.tabs.create({ url: "https://nyaa.si/view/" + notifID });
})

const fetchWithErrorCatching = async (link, options = {}) => {
    const res = await fetch(link, options);
    if (res.status == 200) {
        return res;
    }
    return undefined;
};

//prettier-ignore
setInterval(() => {
    console.log('===============================\nChecking for new comments\n===============================')
    chrome.storage.sync.get("NyaaUtilSettings", function (result) {
        Object.entries(result.NyaaUtilSettings.options.subscribedThreads).forEach(([key, value]) => {
            (async () => {
                const link = "https://nyaa.si/view/" + key;
                const req = await fetchWithErrorCatching(link, {
                    "headers": {
                        "User-Agent": navigator.userAgent
                    }
                })
                if (req == undefined) {
                    return
                }
                const data = await (req).text();

                const commentsLength = $(data).find(
                    "div#comments > #collapse-comments > div.panel.panel-default.comment-panel"
                ).length;
                if (commentsLength > value) {
                    let message = `${commentsLength - value} new comment`;
                    if (commentsLength - value > 1) {
                        message += "s";
                    }
                    message += "!"

                    chrome.notifications.create(key, {
                        type: "basic",
                        iconUrl: "assets/128.png",
                        title: data.match(/<meta property="og:title" content="(.*?) :: Nyaa">/)[1],
                        message,
                        priority: 2,
                    });
                    result.NyaaUtilSettings.options.subscribedThreads[key] = commentsLength;
                    chrome.storage.sync.set({
                        NyaaUtilSettings: result.NyaaUtilSettings,
                    });
                    console.log(
                        `New comments found for ${key}.`
                    );
                } else if (commentsLength < value) {
                    result.NyaaUtilSettings.options.subscribedThreads[key] = commentsLength;
                    chrome.storage.sync.set({
                        NyaaUtilSettings: result.NyaaUtilSettings,
                    });
                    console.log(
                        `Found less comments than the saved value for ${key}.`
                    );
                } else {
                    // nothing happens
                }
            })();
        });
    });
}, 1000 * 60 * 15); // every 1 minute
