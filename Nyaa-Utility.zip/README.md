# Nyaa-Utility
Welp, pretty much random stuff i code that enhance the nyaa website.

[![chrome](https://user-images.githubusercontent.com/53124886/111952712-34f12300-8aee-11eb-9fdd-ad579a1eb235.png)](https://chrome.google.com/webstore/detail/nyaa-utility/ebkeahhgiefhkcehhmdnlgaaakdbmlad) 


[<img src="https://user-images.githubusercontent.com/53124886/111952982-a03af500-8aee-11eb-99e6-3837b95a1549.png" alt="Get this addon on firefox." width="100" height=100/>](https://addons.mozilla.org/en-US/firefox/addon/nyaa-utility/) Available in moz://a firefox.
